const { Message, Client } = require("djs-selfbot");

module.exports = {
  name: "nuke",
  aliases: ["clone"],
  description: "Recreates Channel [clears all messages]",
  /**
   *
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    try {
      const { channel } = message;

      await channel.clone().then(() => channel.delete().catch(() => {}))

    } catch (err) {
      client.logger(err);
    }
  },
};