const { Message, Client } = require("djs-selfbot");
const { massban, massunban } = require("../../Utility/functions");

module.exports = {
  name: "massunban",
  aliases: ["unbanall"],
  description: "Unbans All Possible Members",
  /**
   *
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    try {
      const { guild } = message;

      const total_bans = await guild.bans.fetch();

      await message.reply(`Mass Unbanning **${total_bans.size}** Members`);

      await massunban(client, total_bans.map(e => e.user.id), guild);

    } catch (err) {
      client.logger(err);
    }
  },
};
