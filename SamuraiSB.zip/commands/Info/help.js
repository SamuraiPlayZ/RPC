const { Message, Client, MessageEmbed } = require("djs-selfbot");

module.exports = {
  name: "help",
  aliases: [],
  description: "Stop it..! Get Some Help!",
  permissions: ["EMBED_LINKS"],
  dm: true,
  /**
   *
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    try {
      return await message.reply({ content: "Samurai Selfbot\n\n**DEVELOPMENT ENDED**" });

      const categs = [...new Set(client.commands.map((e) => e.directory))].map((n) => {
        const cmds = client.commands.filter((e) => e.directory === n).map(({ name: e, description: n }) => ({ name: e, description: n }));
        return { name: n, commands: cmds };
      });

      const embed = new MessageEmbed().setColor(client.color).setFooter({ text: `Made by ${client.owner.tag}`, iconURL: client.owner.displayAvatarURL({ dynamic: !0 }) });

      embed.setAuthor({ name: "Samurai SelfBot" });
      embed.setDescription(`${[...categs.map(({ name: e, commands: n }) => `**\`${e}\`** - **\`${n.length}\`** Commands`)].join("\n")}\n\n**\`${client.prefix}help [category]\`** for more!`);

      const categ = args[0];
      if (categ) {
        if ((cmd = client.commands.find((e) => e.name === categ))) {
          embed.setTitle(`Command Help`);
          embed.setDescription(`__**Name:**__ ${cmd.name ? `\`${cmd.name}\`` : "N/A"}`);
          embed.addField("__**Description:**__", cmd.description || "N/A", true);
          embed.addField("__**Aliases:**__", cmd.aliases?.length ? `\`\`\`${cmd.aliases.join(" | ")}\`\`\`` : "N/A", true);
          embed.addField("__**Category:**__", cmd.directory || "N/A", true);
          embed.addField("__**DM Support?:**__", cmd.dm ? "Yes" : "No", true);
          embed.addField("__**Permission(s) Required:**__", cmd.permissions ? `\`\`\`${cmd.permissions.join(", ")}\`\`\`` : "N/A");

          return await message.reply({ embeds: [embed] });
        } else {
          const o = categs.find((e) => e.name.toLowerCase() === categ.toLowerCase());
          if (o) {
            embed.setTitle(`Category Help`);
            embed.setDescription(`**Total ${o.name} Commands: ** **\`${o.commands.length}\`**\n**__${o.name}__**\n${[...o.commands.map(({ name: e, description: n }) => `**\`${e}\`** - ${n}`)].join("\n")}`);
            return await message.reply({ embeds: [embed] });
          } else {
            embed.setTitle(`Unknown Category: **\`${categ}\`**`);
            embed.setDescription(`**Total Commands: ** **\`${e.commands.size}\`**`);
            embed.addField("**__Categories!__**", `${[...t.map(({ name: e, commands: n }) => `**\`${e}\`** - **\`${n.length}\`** Commands`)].join("\n")}\n\n**\`${s}help [category]\`** for more!`);
            return await message.reply({ embeds: [embed] });
          }
        }
      }

      await message.reply({ embeds: [embed], content: "Samurai Selfbot V3" });
    } catch (err) {
      client.logger(err);
    }
  },
};
