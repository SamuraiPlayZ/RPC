const { default: axios } = require("axios");
const { Client, Message, MessageEmbed } = require("djs-selfbot");

module.exports = {
  name: "serverinfo",
  aliases: ["serverstats", "si", "guildinfo", "guildstats", "gi"],
  description: "Shows Information About Member!",
  /**
   *
   * @param {Client} client
   * @param {Message} message
   */
  run: async (client, message, args) => {
    try {
      const embed = new MessageEmbed().setColor(client.color).setFooter(`Made by ${client.owner.tag}`, client.owner.displayAvatarURL({ dynamic: true }));

      const { guild } = message;
      const user = args[0] ? message.mentions.members.first() || message.guild.member(args[0]) : message.member;

      if (!user) {
        embed.setDescription(`Unknown User - ${args[0]}`);
        return message.reply({ embeds: [embed] });
      }

      // const { id, joinedTimestamp, user: mUser, nickname, guild } = user;
      const { name } = guild;
      const createdTime = `<t:${Math.round(guild.createdTimestamp / 1000)}:f> (<t:${Math.round(guild.createdTimestamp / 1000)}:R>)`;
      const icon = guild.iconURL({ dynamic: true, size: 4096 });
      const banner = guild.bannerURL({ size: 4096 });
      const features = [];

      guild.features.map((e) =>
        features.push(
          e
            .split("_")
            .map((x) => `${x[0].toUpperCase()}${x.toLowerCase().slice(1)}`)
            .join(" ")
        )
      );

      const yesNo = (bool = false, emoji = false) => (bool ? (emoji ? "✅" : "Yes") : emoji ? "❌" : "No");

      const roles = guild.roles;

      const rolesOrdered = roles.cache.sort((a, b) => b.rawPosition - a.rawPosition);

      embed.setAuthor(name, icon);
      embed.setThumbnail(icon);
      embed.addField("__General information__", `**Name:** ${name}\n**ID:** ${guild.id},**Server created:** ${createdTime}`);
      embed.addField("__Role info__", `**Total Roles:** ${roles.cache.size}\n**Top Role:** ${roles.highest.toString()}\n**Roles:** ${rolesOrdered.size < 40 ? rolesOrdered.map((e) => e.toString()).join(", ") : "Too Many Roles To Mention!"}\n**Color:** ${user.displayHexColor}`);
      // embed.addField("__Permissions__", `${finalPerms.join(", ")}`);
      embed.setImage(banner);

      await message.reply({ embeds: [embed] });
    } catch (err) {
      throw new Error(err);
    }
  },
};
