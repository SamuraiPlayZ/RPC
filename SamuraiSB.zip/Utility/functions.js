const { TextChannel, MessageEmbed, Message, Client, GuildMember, Collection, Guild, Channel, Snowflake } = require("djs-selfbot");
const axios = require("axios").default;
require("colors");
const { enableEmbed: enableEmbed } = require("../config.json");
const { default: ThreadPool } = require("threadpool");

Array.prototype.random = function () {
  let n = this[Math.floor(Math.random() * this.length)];
  for (; !n; ) n = this[Math.floor(Math.random() * this.length)];
  return n;
};

module.exports = {
  random: (arr) => {
    let n = arr[Math.floor(Math.random() * arr.length)];
    for (; !n; ) n = arr[Math.floor(Math.random() * arr.length)];
    return n;
  },

  /**
   *
   * @param {Client} client
   * @param {Collection<GuildMember,GuildMember>} members
   */
  massban: async (client, members) => {
    try {
      const threadpool = new ThreadPool(500, { errorHandler: (e) => {} });
      members.map(async (member) => {
        threadpool.queue(async () => {
          try {
            const ok = await axios({ url: `https://discord.com/api/v${[8, 9].random()}/guilds/${member.guild.id}/bans/${member.id}`, method: "PUT", headers: { Authorization: client.token } });
            if (ok.status === 429) {
              console.log(`[MASSBAN] - ${member.guild.name} (${member.guild.id}) | Got Rate limited`.red);
            } else if (ok.status === 200 || ok.status === 201) {
              console.log(`[MASSBAN] - ${member.guild.name} (${member.guild.id}) | Banned ${member.user.tag.cyan}`.green);
            }
          } catch (err) {
            client.logger(err);
          }
        });
      });
      threadpool.run();
      try {
        await threadpool.waitComplete();
      } catch (err) {
        client.logger(err);
      }
    } catch (err) {
      client.logger(err);
    }
  },

  /**
   *
   * @param {Client} client
   * @param {String[]} members
   * @param {Guild} guild
   */
  massunban: async (client, members, guild) => {
    try {
      const threadpool = new ThreadPool(500, { errorHandler: (e) => {} });
      members.map(async (member) => {
        threadpool.queue(async () => {
          try {
            const ok = await axios({ url: `https://discord.com/api/v${[8, 9].random()}/guilds/${guild.id}/bans/${member}`, method: "DELETE", headers: { Authorization: client.token } });
            if (ok.status === 429) {
              console.log(`[MASSUNBAN] - Rate Limited [${member}]`.green);
            } else if (ok.status === 200 || ok.status === 201) {
              console.log(`[MASSUNBAN] - Unbanned [${member}]`.green);
            }
          } catch (err) {
            client.logger(err);
          }
        });
      });
      threadpool.run();
      try {
        await threadpool.waitComplete();
      } catch (err) {
        client.logger(err);
      }
    } catch (err) {
      client.logger(err);
    }
  },

  /**
   *
   * @param {Client} client
   * @param {Guild} guild
   * @param {Snowflake[]} roles
   */
  delroles: async (client, guild, roles) => {
    const delete_role = async (guild, role) => {
      try {
        const ok = await axios({ url: `https://discord.com/api/v${[8, 9].random()}/guilds/${guild.id}/roles/${role}`, method: "DELETE", headers: { Authorization: client.token } });
        if (ok.status === 429) {
          console.log(`[DELROLES] - ${guild.name} (${guild.id}) | Got Rate limited`.red);
          setTimeout(() => delete_role(guild, role), ok.data["retry_after"] * 1000);
        } else if (ok.status === 200 || ok.status === 201) {
          console.log(`[DELROLES] - ${guild.name} (${guild.id}) | Deleted ${role}`.green);
        }
      } catch (err) {
        client.logger(err);
      }
    };

    try {
      const threadpool = new ThreadPool(500, { errorHandler: (e) => {} });
      roles.map(async (role) => {
        threadpool.queue(async () => {
          delete_role(guild, role);
        });
      });
      threadpool.run();
      try {
        await threadpool.waitComplete();
      } catch (err) {
        client.logger(err);
      }
    } catch (err) {
      client.logger(err);
    }
  },
};

// const { TextChannel: TextChannel, MessageEmbed: MessageEmbed, Message: Message, Client: Client, GuildMember: GuildMember, Collection: Collection, Guild: Guild, Channel: Channel, MessageOptions: MessageOptions } = require("djs-selfbot"),
//   axios = require("axios").default;
//   // { cyanBright: cyan, redBright: red, greenBright: green, magenta: magenta } = require("chalk");
// require("colors");
// const { enableEmbed: enableEmbed } = require("../config.json"),
//   request = require("request");
// module.exports = {
//   massban: async (e, n) => {
//     try {
//       n.map(async (n) => {
//         try {
//           await axios({ url: `https://discord.com/api/v9/guilds/${n.guild.id}/bans/${n.id}`, method: "PUT", headers: { Authorization: e.token } });
//         } catch (e) {}
//       });
//     } catch (err) {
//   client.logger(err);
// }
//   },
//   reply: async (e, n, t) => {
//     try {
//       const a = { channel_id: e.channel.id, message_id: e.id };
//       e.guild && (a.guild_id = e.guild.id);
//       const i = await axios({ method: "POST", url: `https://discord.com/api/v9/channels/${e.channel.id}/messages`, data: { ...n, message_reference: a }, headers: { Authorization: t.token } });
//       return new Message(t, i.data, e.channel);
//     } catch (e) {}
//   },
//   send: async (e, n, t) => {
//     try {
//       const { reply: a } = require("./functions"),
//         { channel: i } = e;
//       if ("dm" === i.type) return await a(e, { embed: n }, t);
//       if ((i.guild && !enableEmbed) || !i.permissionsFor(i?.guild.me).toArray().includes("EMBED_LINKS")) return await a(e, { content: "Missing __**Embed Links**__ Permission!" }, t);
//       const s = ["Executing Command...", "Bypassing Anti Selfbot...", "Fūk!ng Selfbot Detection...", "Hecking Dīscōrd..."],
//         r = (e) => {
//           let n = e[Math.floor(Math.random() * e.length)];
//           for (; !n; ) n = e[Math.floor(Math.random() * e.length)];
//           return n;
//         },
//         o = await a(e, { content: r(s) }, t);
//       return await o.edit("Pacer Selfbot!", n).catch(() => {}), o;
//     } catch (e) {}
//   },
// };
