const { default: axios } = require("axios");
const { Client } = require("djs-selfbot");

/**
 *
 * @param {Token} tuken
 * @param {Client} client
 */
module.exports = (tuken, client) => {
  try {
    const myClient = new Client();
    myClient.login(tuken);
    myClient.on("ready", () => {
      client.logger(`[NITRO_SNIPER] Started!`);
      myClient.on("message", async (message) => {
        if (message.content.includes("discord.gift/") || message.content.includes("discordapp.com/gifts/")) {
          try {
            const nitro_url_regex = /(discord\.(gift)|discordapp\.com\/gift)\/.+[a-z]/;

            const url_from_msg = nitro_url_regex.exec(message.content);
            const nitro_code = url_from_msg[0].split("/")[1] || message.content.slice("https://discord.gift/");

            client.logger(`[NITRO_SNIPER] Got Nitro Code: ${nitro_code}, Trying To Redeem!`);

            try {
              await axios({
                method: "POST",
                url: `https://discordapp.com/api/v6/entitlements/gift-codes/${nitro_code}/redeem`,
                headers: {
                  Authorization: tuken,
                },
              });
              client.logger(`[NITRO_SNIPER] Nitro Code: ${nitro_code}, Succesfully Claimed!`);
            } catch {
              client.logger(`[NITRO_SNIPER] Nitro Code: ${nitro_code}, Failed To Redeem!`);
            }
          } catch (e) {
            client.logger(e);
          }
        }
      });
    });
  } catch (error) {
    console.log(error);
  }
};
