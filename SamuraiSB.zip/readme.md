# SB is not ready yet

# Replit
1. Put Token in Secrets
2. Click Run Button
3. Happy Hacking..!

# Made by Samurai :P
